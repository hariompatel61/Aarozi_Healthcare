Aarozi Healthcare Portable LIS v2.4.0
No Admin rights required.
Extract this folder and double click Aarozi-LIS-Launcher.bat to run locally on http://localhost:3000.
LAN Workstations can connect via http://<YOUR-IP>:3000
